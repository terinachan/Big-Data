# FLbigdataViz

Big Data: Data Visualisation

This repo contains the files required to complete the exercises:

- Analyse customer campaign results using Tableau
- Create an interactive map using D3.js
- Create a network dataset visualisation using D3.js

Course starts 27 June 2016, sign now https://www.futurelearn.com/courses/big-data-visualisation
